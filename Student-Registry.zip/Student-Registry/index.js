require("dotenv").config();
const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "home.html"));
});

app.get("/students", (req, res) => {
    db.query("SELECT * FROM students", (err, results) => {
        if (err) return res.status(500).json({ error: "Database error" });
        res.json(results);
    });
});

app.post("/students", (req, res) => {
    const { name, email, enrollment_date } = req.body;
    if (!name || !email || !enrollment_date) {
        return res.status(400).json({ error: "All fields are required" });
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
        return res.status(400).json({ error: "Invalid email format" });
    }
    const query =
        "INSERT INTO students (name, email, enrollment_date) VALUES (?, ?, ?)";
    db.query(query, [name, email, enrollment_date], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Student added successfully" });
    });
});

app.get("/students/:id", (req, res) => {
    const { id } = req.params;
    db.query("SELECT * FROM students WHERE id = ?", [id], (err, results) => {
        if (err || !results.length)
            return res.status(404).json({ error: "Student not found" });
        res.json(results[0]);
    });
});

app.post("/students/:id", (req, res) => {
    const { id } = req.params;
    const { name, email, enrollment_date } = req.body;
    if (!name || !email || !enrollment_date) {
        return res.status(400).json({ error: "All fields are required" });
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
        return res.status(400).json({ error: "Invalid email format" });
    }
    const query =
        "UPDATE students SET name = ?, email = ?, enrollment_date = ? WHERE id = ?";
    db.query(query, [name, email, enrollment_date, id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Student updated successfully" });
    });
});

app.post("/students/:id/delete", (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM students WHERE id = ?", [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Student deleted successfully" });
    });
});

app.listen(PORT, '0.0.0.0', () =>
    console.log(`Server running on http://0.0.0.0:${PORT}`),
);
