const mysql = require("mysql");
require("dotenv").config();

const connection = mysql.createConnection({
    host: 'sql3.freesqldatabase.com',
    user: 'sql3776777',
    password: 'SzSrZv7FSt',
    database: 'sql3776777',
    port: 3306
});

function connectWithRetry(attempts = 5, delay = 5000) {
    connection.connect((error) => {
        if (error && attempts > 0) {
            console.error(
                `Connection failed, retrying (${attempts} left):`,
                error,
            );
            setTimeout(() => connectWithRetry(attempts - 1, delay), delay);
        } else if (error) {
            console.error("Database connection failed:", error);
            process.exit(1);
        } else {
            console.log("Successfully connected to the database.");
        }
    });
}

connectWithRetry();
module.exports = connection;
